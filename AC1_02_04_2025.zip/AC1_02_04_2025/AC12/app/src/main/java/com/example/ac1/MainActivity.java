package com.example.ac1;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<Book> bookList;
    private DatabaseHelper dbHelper;
    private FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        fab = findViewById(R.id.fab);
        dbHelper = new DatabaseHelper(this);
        bookList = dbHelper.getAllBooks();
        updateListView();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(MainActivity.this, BookFormActivity.class);
            intent.putExtra("bookId", bookList.get(position).getId());
            startActivity(intent);
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Excluir Livro")
                    .setMessage("Tem certeza que deseja excluir este livro?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        dbHelper.deleteBook(bookList.get(position).getId());
                        bookList.remove(position);
                        updateListView();
                    })
                    .setNegativeButton("Não", null)
                    .show();
            return true;
        });

        fab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BookFormActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        bookList = dbHelper.getAllBooks();
        updateListView();
    }

    private void updateListView() {
        ArrayList<String> bookTitles = new ArrayList<>();
        for (Book book : bookList) {
            bookTitles.add(book.getTitle() + " - " + book.getAuthor());
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookTitles);
        listView.setAdapter(adapter);
    }
}