package com.example.ac1;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BookFormActivity extends AppCompatActivity {
    private EditText titleInput, authorInput;
    private Spinner categorySpinner;
    private CheckBox readCheckBox;
    private Button saveButton;
    private DatabaseHelper dbHelper;
    private int bookId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_form);

        titleInput = findViewById(R.id.titleInput);
        authorInput = findViewById(R.id.authorInput);
        categorySpinner = findViewById(R.id.categorySpinner);
        readCheckBox = findViewById(R.id.readCheckBox);
        saveButton = findViewById(R.id.saveButton);
        dbHelper = new DatabaseHelper(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.book_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        bookId = getIntent().getIntExtra("bookId", -1);
        if (bookId != -1) {
            Book book = dbHelper.getBookById(bookId);
            if (book != null) {
                titleInput.setText(book.getTitle());
                authorInput.setText(book.getAuthor());
                categorySpinner.setSelection(adapter.getPosition(book.getCategory()));
                readCheckBox.setChecked(book.isRead());
            }
        }

        saveButton.setOnClickListener(v -> {
            String title = titleInput.getText().toString().trim();
            String author = authorInput.getText().toString().trim();
            String category = categorySpinner.getSelectedItem().toString();
            boolean isRead = readCheckBox.isChecked();

            if (title.isEmpty() || author.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            Book book = new Book(bookId == -1 ? -1 : bookId, title, author, category, isRead);
            if (bookId == -1) {
                dbHelper.insertBook(book);
            } else {
                dbHelper.updateBook(book);
            }
            finish();
        });
    }
}