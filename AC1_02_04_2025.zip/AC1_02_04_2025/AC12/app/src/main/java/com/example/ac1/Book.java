package com.example.ac1;

public class Book {
    private int id;
    private String title;
    private String author;
    private String category;
    private boolean isRead;

    public Book(int id, String title, String author, String category, boolean isRead) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
        this.isRead = isRead;
    }

    public Book(String title, String author, String category, boolean isRead) {
        this(-1, title, author, category, isRead);
    }

    public int getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }

    public String getAuthor() {
        return this.author;
    }

    public String getCategory() {
        return this.category;
    }

    public boolean isRead() {
        return this.isRead;
    }
}