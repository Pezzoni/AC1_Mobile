package com.example.ac1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class Salvar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salvar);

        CheckBox checkBoxNotificacoes = findViewById(R.id.cbNotificacoes);
        CheckBox checkBoxModoEscuro = findViewById(R.id.cbModoEscuro);
        CheckBox checkBoxLembrarLogin = findViewById(R.id.cbLembrarLogin);
        Button buttonSalvar = findViewById(R.id.btnSalvar);

        buttonSalvar.setOnClickListener(view -> {
            StringBuilder preferenciasEscolhidas = new StringBuilder();

            if (checkBoxNotificacoes.isChecked()) preferenciasEscolhidas.append("Receber notificações\n");
            if (checkBoxModoEscuro.isChecked()) preferenciasEscolhidas.append("Modo escuro\n");
            if (checkBoxLembrarLogin.isChecked()) preferenciasEscolhidas.append("Lembrar login\n");

            if (preferenciasEscolhidas.length() > 0) {
                Toast.makeText(this, "Preferências escolhidas:\n" + preferenciasEscolhidas, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Nenhuma preferência foi escolhida.", Toast.LENGTH_LONG).show();
            }
        });
    }
}