package com.example.ac1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class CadastroRoupa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_roupa);

        EditText inputNome = findViewById(R.id.etNome);
        EditText inputIdade = findViewById(R.id.etIdade);
        EditText inputUF = findViewById(R.id.etUF);
        EditText inputCidade = findViewById(R.id.etCidade);
        EditText inputTelefone = findViewById(R.id.etTelefone);
        EditText inputEmail = findViewById(R.id.etEmail);
        RadioGroup groupTamanho = findViewById(R.id.rgTamanho);
        CheckBox checkVermelho = findViewById(R.id.cbVermelho);
        CheckBox checkAzul = findViewById(R.id.cbAzul);
        CheckBox checkVerde = findViewById(R.id.cbVerde);
        CheckBox checkPreto = findViewById(R.id.cbPreto);
        Button buttonCadastrar = findViewById(R.id.btnCadastrar);
        TextView resultadoFinal = findViewById(R.id.tvResultado);

        buttonCadastrar.setOnClickListener(view -> {
            String nome = inputNome.getText().toString();
            String idade = inputIdade.getText().toString();
            String uf = inputUF.getText().toString();
            String cidade = inputCidade.getText().toString();
            String telefone = inputTelefone.getText().toString();
            String email = inputEmail.getText().toString();

            int idTamanhoSelecionado = groupTamanho.getCheckedRadioButtonId();
            RadioButton tamanhoSelecionado = findViewById(idTamanhoSelecionado);
            String tamanho = tamanhoSelecionado != null ? tamanhoSelecionado.getText().toString() : "Não selecionado";

            StringBuilder coresPreferidas = new StringBuilder();
            if (checkVermelho.isChecked()) coresPreferidas.append("Vermelho ");
            if (checkAzul.isChecked()) coresPreferidas.append("Azul ");
            if (checkVerde.isChecked()) coresPreferidas.append("Verde ");
            if (checkPreto.isChecked()) coresPreferidas.append("Preto ");

            String resultado = "Nome: " + nome + "\n" +
                    "Idade: " + idade + "\n" +
                    "UF: " + uf + "\n" +
                    "Cidade: " + cidade + "\n" +
                    "Telefone: " + telefone + "\n" +
                    "Email: " + email + "\n" +
                    "Tamanho: " + tamanho + "\n" +
                    "Cores Preferidas: " + coresPreferidas.toString();

            resultadoFinal.setText(resultado);
        });
    }
}