package com.example.ac1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class User extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        EditText inputNome = findViewById(R.id.etNome);
        EditText inputIdade = findViewById(R.id.etIdade);
        Button buttonVerificar = findViewById(R.id.btnVerificar);
        TextView resultadoTexto = findViewById(R.id.tvResultado);

        buttonVerificar.setOnClickListener(view -> {
            String nome = inputNome.getText().toString();
            String idadeTexto = inputIdade.getText().toString();
            if (!idadeTexto.isEmpty()) {
                int idade = Integer.parseInt(idadeTexto);
                if (idade >= 18) {
                    resultadoTexto.setText(nome + ", você é maior de idade.");
                } else {
                    resultadoTexto.setText(nome + ", você é menor de idade.");
                }
            } else {
                resultadoTexto.setText("Por favor, insira uma idade válida.");
            }
        });
    }
}