package com.example.ac1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.CheckBox;

public class CheckBoxActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_box);

        EditText inputNome = findViewById(R.id.etNome);
        Button buttonGerar = findViewById(R.id.btnGerar);
        LinearLayout layoutCheckBoxes = findViewById(R.id.containerCheckBoxes);

        buttonGerar.setOnClickListener(view -> {

            layoutCheckBoxes.removeAllViews();

            String nomeTexto = inputNome.getText().toString();

            for (int indice = 0; indice < nomeTexto.length(); indice++) {
                char letraAtual = nomeTexto.charAt(indice);
                CheckBox novoCheckBox = new CheckBox(this);
                novoCheckBox.setText(String.valueOf(letraAtual));
                layoutCheckBoxes.addView(novoCheckBox);
            }
        });
    }
}