package com.example.ac1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calculadora extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        EditText inputNumero1 = findViewById(R.id.etNumero1);
        EditText inputNumero2 = findViewById(R.id.etNumero2);
        Button buttonAdicionar = findViewById(R.id.btnAdicionar);
        Button buttonSubtrair = findViewById(R.id.btnSubtrair);
        Button buttonMultiplicar = findViewById(R.id.btnMultiplicar);
        Button buttonDividir = findViewById(R.id.btnDividir);
        TextView resultadoTexto = findViewById(R.id.tvResultado);

        buttonAdicionar.setOnClickListener(view -> {
            double numero1 = Double.parseDouble(inputNumero1.getText().toString());
            double numero2 = Double.parseDouble(inputNumero2.getText().toString());
            double resultado = numero1 + numero2;
            resultadoTexto.setText("Resultado: " + resultado);
        });

        buttonSubtrair.setOnClickListener(view -> {
            double numero1 = Double.parseDouble(inputNumero1.getText().toString());
            double numero2 = Double.parseDouble(inputNumero2.getText().toString());
            double resultado = numero1 - numero2;
            resultadoTexto.setText("Resultado: " + resultado);
        });

        buttonMultiplicar.setOnClickListener(view -> {
            double numero1 = Double.parseDouble(inputNumero1.getText().toString());
            double numero2 = Double.parseDouble(inputNumero2.getText().toString());
            double resultado = numero1 * numero2;
            resultadoTexto.setText("Resultado: " + resultado);
        });

        buttonDividir.setOnClickListener(view -> {
            double numero1 = Double.parseDouble(inputNumero1.getText().toString());
            double numero2 = Double.parseDouble(inputNumero2.getText().toString());
            if (numero2 != 0) {
                double resultado = numero1 / numero2;
                resultadoTexto.setText("Resultado: " + resultado);
            } else {
                resultadoTexto.setText("Erro: Divisão por zero!");
            }
        });
    }
}